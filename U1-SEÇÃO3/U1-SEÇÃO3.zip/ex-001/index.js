// Exercício 1
function boasVindas() {
  alert("Bem-vindo ao site!");
}
window.onload = boasVindas; // Executa a função ao carregar a página