// Exercício 4
function paraCaixaAlta(texto) {
  return texto.toUpperCase();
}
