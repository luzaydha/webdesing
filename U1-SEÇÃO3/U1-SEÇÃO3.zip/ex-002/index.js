// Exercício 2
function ehPar(numero) {
  return numero % 2 === 0;
}