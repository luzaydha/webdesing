// Exercício 7
function valorComPorcentagem(valor, porcentagem) {
  return valor + (valor * porcentagem / 100);
}