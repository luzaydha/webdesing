// Exercício 9
function paraBinario(numero) {
  return numero.toString(2);
}