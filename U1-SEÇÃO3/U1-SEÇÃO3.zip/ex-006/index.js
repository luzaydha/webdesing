// Exercício 6
function inverterArray(arr) {
  return arr.slice().reverse();
}